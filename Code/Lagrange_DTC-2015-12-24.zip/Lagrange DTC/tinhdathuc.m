%T�nh gia tri da thuc X tai h vs X nhap vao duoi dang mang
function P=tinhdathuc(X,h);
b=X(1);
n=length(X);
for k=2:n;
    b=b*h+X(k);
end
disp(b);
end