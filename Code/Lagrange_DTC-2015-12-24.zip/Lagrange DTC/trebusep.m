%X la cac gia tri tai cac diem x0,x1,x2....
%Y la cac gia tri tai cac diem y0 y1 y2.... tuong ung
%tu c�c gi� tri X[x1,x2,x3,..] va Y[y1,y2,y3,..] ta se tim da thuc lagrange
% ta se tim moc noi suy toi uu vs x trong khoang minX v� maxX, dung
%lagrange o tren de tim gia tri Y tuong ung,sau do voi cap (X,Y) toi uu se
% t�m da thuc noi suy 

function p=trebusep(X,Y)
%tim ham noi suy Lagrange
%kiem tra so gia tri cua X va Y nhap vao co bang nhau khong
if length(X)~=length(Y)
    error('nhap thua gia tri');
end
%kiem tra,neu co 2 gia tri cua X trung nhau(Xi=Xj) ma 2 gia tri cua Y tuong ung
%giong nhau thi xoa di 1 cap (X,Y), neu ma Y khac nhau(Yi!=Yj) thi bao loi
tt=0;
while tt<length(X);
    tt=tt+1;
    th=0;
    %tt v� th l� 2 bien chay de so s�nh cac gia tri (X,Y)tt va (X,Y)th
    while th<length(X);
    th=th+1;    
            if th~=tt;           
                if X(th)== X(tt);
                    if Y(th)~=Y(tt)                
                          error('gia tri nhap vao sai,nhap lai gia tri');
                       %loi do Xtt=Xth m� Ytt != Yth
                     else X(th)=[];
                          Y(th)=[];
              %neu Xth=Xtt va Yth=Ytt thi xoa di cap (X,Y)th
                    end
       
                end
        
    end
    end
end
%ap dung cong thuc tinh da thuc noi suy Lagrange
    n=length(X);%do dai mang X
    u=zeros(1,n);%ma tran 0 co 1 hang n cot
    t=ones(1,1);%ma tran 1 co 1 hang 1 cot
for l=1:n
    t=conv(t,[1 -X(l)]);%nh�n 2 da thuc: t v� da thuc bac nhat x-X(l)(vs X(l) la phan tu thu l cua mang X da nhap vao)
end;
%t�m duoc da thuc t=(x-X(1)).(x-X(2))....(x-X(n)).
for ll=1:n
    m=1;
    for lll=1:n
        if lll~=ll
        m=m*(X(ll)-X(lll));
        end;
        %tinh duoc so
        %m=(X(ll)-X(1))...(X(ll)-X(lll-1)).(X(ll)-X(lll+1))...X(ll-X(n))
    end;
        u=u+(Y(ll)/m)*deconv(t,[1 -X(ll)]);
        %deconv l� chia da thuc t cho da thuc x-X(ll)
        %so m=(X(ll)-X(1))...(X(ll)-X(lll-1)).(X(ll)-X(lll+1))...X(ll-X(n))
        %da thuc t=(x-X(1)).(x-X(2))....(x-X(n))
        %da thuc lagrange thu duoc la u= u1+u2+...+un
end
    
%Tim moc noi suy toi uu
bb=max(X);aa=min(X);%max(X) l� gia tri lon nhat trong mang X
n=length(X);
G=zeros(1,n);%ma tran 0 c� 1 h�ng n cot
for ij=1:n
    G(ij)=(1/2)*((bb-aa)*cos((2*ij-1)/(2*ij))*pi+bb+aa);
    %cong thuc tim moc noi suy toi uu nhu sach
end
Z=polyval(u,G);%Z l� mang cac gia tri cua da thuc lagrange(u) tai cac moc noi suy toi uu(m?ng G)
uuu=zeros(1,n);
    ttt=ones(1,1);
for l=1:n
    ttt=conv(ttt,[1 -G(l)]);%nhan 2 da thuc
end; %thu ?c ?a th?c ttt=(x-G(1))(x-G(2))......(x-G(n))
for ll=1:n
    mmm=1;
    for lll=1:n
        if lll~=ll
        mmm=mmm*(G(ll)-G(lll));
        end;%so mmm(ll)=(G(ll)-G(1))...(G(ll)-G(lll-1)).(G(ll)-G(lll+1))...G(ll)-G(n))
    end;
        uuu=uuu+(Z(ll)/mmm)*deconv(ttt,[1 -G(ll)]);%deconv l� l?nh chia 2 da th?c
        %uuu l� da thuc trebusep thu duoc uuu=uuu1+uuu2+...+uuun;
        %mmm(ll)=(G(ll)-G(1))...(G(ll)-G(lll-1)).(G(ll)-G(lll+1))...G(ll)-G(n))
end
disp('da thuc can tim theo trebusep la');
dathuc=poly2sym(uuu,'x');
%bieu dien tu dang mang 1 chieu ve dang ham f(x)
P=vpa(dathuc,5);disp(P);
disp('he so theo trebusep sau khi lam tron');disp(uuu);
%chuyen dang phan so ve dang so thuc bieu dien qua toi da 5 chu so
disp('he so khong dung trebusep');disp(u);
kotrebusep=poly2sym(u,'x');
Q=vpa(kotrebusep,5);
disp('da thuc khong tinh theo trebusep');
disp(Q);
end



    