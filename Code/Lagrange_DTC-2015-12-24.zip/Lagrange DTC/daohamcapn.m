%t�nh dao ham cap qw cua da thuc u tai h
%u duoc nhap vao duoi dang mang
%VD daohamcapn([1 3 3 1],2,3) t�nh dao ham cap 3 cua x^3+3x^2+3x+1 tai x=2 
function P=daohamcapn(u,h,qw)
q=length(u);
if qw<q
tk=zeros(1,q-qw);
for mg=1:(q-qw)
    tk(mg)=u(mg)*factorial(q-mg)/factorial(q-qw-mg);%factorial l� h�m giai thua
end;
else disp('dao ham = 0');
end;
fprintf('cac he so cua dao ham cap %d la',qw);
disp(tk);
%tinh gia tri cua dao ham cap qw tai diem can tinh
b=tk(1);
nk=length(tk);
for kk=2:nk;
    b=b*h+tk(kk);
end
fprintf('gia tri cua dao ham cap %d tai %.2f la:',qw,h);
disp(b);
end