%X la cac gia tri tai cac diem x0,x1,x2....
%Y la cac gia tri tai cac diem y0 y1 y2.... tuong ung
%VD nhap ham: lagrange123([x1,x2,x3],[y1,y2,y3])
function p=lagrange123(X,Y)
%kiem tra so gia tri cua X va Y nhap vao co bang nhau khong
if length(X)~=length(Y)
    error('nhap thua gia tri');
end
%kiem tra,neu co 2 gia tri cua X trung nhau(Xi=Xj) ma 2 gia tri cua Y tuong ung
%giong nhau thi xoa di 1 cap (X,Y), neu ma Y khac nhau(Yi!=Yj) thi bao loi
tt=0;
while tt<length(X);
    tt=tt+1;
    th=0;
    %tt v� th l� 2 bien chay de so s�nh cac gia tri (X,Y)tt va (X,Y)th
    while th<length(X);
    th=th+1;    
            if th~=tt;           
                if X(th)== X(tt);
                    if Y(th)~=Y(tt)                
                          error('gia tri nhap vao sai,nhap lai gia tri');
                       %loi do Xtt=Xth m� Ytt != Yth
                     else X(th)=[];
                          Y(th)=[];
              %neu Xth=Xtt va Yth=Ytt thi xoa di cap (X,Y)th
                    end
       
                end
        
    end
    end
end
%ap dung cong thuc tinh da thuc noi suy Lagrange
    n=length(X);%do dai mang X
    u=zeros(1,n);%ma tran 0 co 1 hang n cot
    t=ones(1,1);%ma tran 1 co 1 hang 1 cot
for l=1:n
    t=conv(t,[1 -X(l)]);%nh�n 2 da thuc: t v� da thuc bac nhat x-X(l)(vs X(l) la phan tu thu l cua mang X da nhap vao)
end;
%t�m duoc da thuc t=(x-X(1)).(x-X(2))....(x-X(n)).
for ll=1:n
    m=1;
    for lll=1:n
        if lll~=ll
        m=m*(X(ll)-X(lll));
        end;
        %tinh duoc so
        %m=(X(ll)-X(1))...(X(ll)-X(lll-1)).(X(ll)-X(lll+1))...X(ll-X(n))
    end;
        u=u+(Y(ll)/m)*deconv(t,[1 -X(ll)]);
        %deconv l� chia da thuc t cho da thuc x-X(ll)
        %so m=(X(ll)-X(1))...(X(ll)-X(lll-1)).(X(ll)-X(lll+1))...X(ll-X(n))
        %da thuc t=(x-X(1)).(x-X(2))....(x-X(n))
        %da thuc lagrange thu duoc la u= u1+u2+...+un
end
    
disp('da thuc can tim la');
dathuc=poly2sym(u,'x');
%bieu dien tu dang mang 1 chieu ve dang ham f(x)
%VD:[1 2 3]=x^2+2x+3
P=vpa(dathuc,5)
%chuyen ham so "dathuc" dang phan so ve dang so thuc bieu dien qua toi da 5 chu so
%VD:dathuc=1/3x+2/3=0.3333x+0.6667
disp('hay P(x)=');
disp(dathuc);
%in duoi dang he so
disp('he so');
disp(u);
end

         

             







